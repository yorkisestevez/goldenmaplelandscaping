import engineBaseline from '../data/engine-baseline.json';

// Deck rates bracket the engine's $3,700/crew-day card. Hardscape floors come
// straight from the LOCKED all-in rate card ($2,800/crew-day — wages, burden,
// equipment, overhead, and margin already inside; corrected from a stale $2,470
// on 2026-07-28).
// FACTS derive from engine-baseline.json — scripts/check-pricing-parity.ts
// fails the build if these drift from the DeckCraft engine.
// 2026-07-28 — deck was briefly cut to $3,000, then returned to the $3,700
// target: $3,000 sat below the documented $3,400 bottom and roughly halved
// deck gross margin (~$800/day vs ~$1,500/day). Rails stay 3400/4000 around
// the 3700 target. If the target ever moves again, move these rails with it —
// a bottom above the target feeds an incoherent band into line 43.
export const DAILY_PRODUCTION_RATES = {
  bottom: 3400,
  target: engineBaseline.facts.crewDayRateDeck,
  premium: 4000,
} as const;

export const HARDSCAPE_DAILY_RATES = {
  bottom: engineBaseline.facts.crewDayRateHardscape,
  premium: Math.round(engineBaseline.facts.crewDayRateHardscape * 1.13),
} as const;

export const PROJECT_PLANNING_RANGES = {
  frontEntrance: { low: 18000, high: 40000, label: 'Small walkway/front entrance' },
  premiumPatio: { low: 35000, high: 75000, label: 'Premium patio / outdoor room' },
  patioWallDrainage: { low: 50000, high: 100000, label: 'Patio + wall/steps/drainage' },
  fullBackyard: { low: 90000, high: 150000, label: 'Full backyard transformation' },
} as const;

export function applyDailyProductionFloor({
  labourLow,
  labourHigh,
  daysLow,
  daysHigh,
  projectType,
}: {
  labourLow: number;
  labourHigh: number;
  daysLow: number;
  daysHigh: number;
  /** 'deck' floors at the deck day-rate band; everything else (hardscape) at
   *  the locked all-in hardscape card. Omitted = legacy deck-band behaviour. */
  projectType?: string | null;
}) {
  const rates = projectType && projectType !== 'deck'
    ? { bottom: HARDSCAPE_DAILY_RATES.bottom, premium: HARDSCAPE_DAILY_RATES.premium }
    : { bottom: DAILY_PRODUCTION_RATES.bottom, premium: DAILY_PRODUCTION_RATES.premium };
  return {
    labourLow: Math.max(labourLow, daysLow * rates.bottom),
    labourHigh: Math.max(labourHigh, daysHigh * rates.premium),
  };
}

/**
 * Crew-day sanity floor for the PRECISE (takeoff) figure — engine v3.
 *
 * The calibrated $/sqft excavation+install rates undershoot real crew cost on
 * small jobs (a 100 sqft walkway still mobilizes a crew for a day). When the
 * combined on-site figure lands under daysMid × the locked day rate, scale
 * BOTH slices up proportionally so their sum hits the floor exactly (integer
 * cents preserved). Same cost-math-not-marketing rationale as
 * applyDailyProductionFloor above — that one floors the banded range; this
 * one floors the point estimate.
 */
export function applyPreciseCrewFloor({
  excavationCents,
  labourCents,
  daysMid,
  projectType,
}: {
  excavationCents: number;
  labourCents: number;
  daysMid: number;
  projectType?: string | null;
}): { excavationCents: number; labourCents: number; floored: boolean } {
  const rate = projectType && projectType !== 'deck'
    ? HARDSCAPE_DAILY_RATES.bottom
    : DAILY_PRODUCTION_RATES.target;
  const floorCents = Math.round(daysMid * rate * 100);
  const combined = excavationCents + labourCents;
  if (combined <= 0 || combined >= floorCents) {
    return { excavationCents, labourCents, floored: false };
  }
  const scaledExcavation = Math.round(excavationCents * (floorCents / combined));
  return {
    excavationCents: scaledExcavation,
    labourCents: floorCents - scaledExcavation,
    floored: true,
  };
}

// NOTE: there is deliberately no getEstimatorMinimumFloor() any more.
// The estimator used to clamp every result up to a per-project-type job
// minimum ($18K–$90K), which meant a small walkway that genuinely costed out
// at $9K was shown as $18K. Removed 2026-07-27 — every visitor now prices
// their real project, whatever the size. (As of 2026-08-14 the itemized
// breakdown is free to everyone — the gate moved to SAVING the build, see
// EstimateLeadCapture.tsx / buildPermalink.ts — but qualification was never
// what this floor removal was about: it's that the site should never show a
// number padded above what a project actually costs.)
//
// The labour day-rate floor in applyDailyProductionFloor() above is NOT the
// same thing and stays: it's real cost math (a crew-day costs what it costs),
// not a marketing minimum. Removing that one would let the estimator quote
// jobs below Golden Maple's actual cost to show up.

/** Format a PROJECT_PLANNING_RANGES entry as "$XK–$YK+". */
const fmtK = (n: number) => `$${Math.round(n / 1000)}K`;

// This copy renders under EVERY result on the estimator's result step — including
// a $7,500 100-sqft build, since there is deliberately no job minimum (see above).
// It must therefore describe what GOLDEN MAPLE BUILDS across its project history,
// never the specific number the calculator just produced for THIS visitor — those
// are two different claims and conflating them reads as "no minimum" contradicting
// itself in the same sentence. Sourced from PROJECT_PLANNING_RANGES so there is one
// number, not three hand-copied literals drifting apart across files.
export function getEstimatorRangeCopy(projectType: string | null, selectedElements: string[] = []) {
  const r = PROJECT_PLANNING_RANGES;
  if (projectType === 'full') return `Full backyard transformations we build commonly land ${fmtK(r.fullBackyard.low)}–${fmtK(r.fullBackyard.high)}+ when patio, walls, lighting, fire, kitchen, drainage, or grade work are included — your configured scope above prices independently.`;
  if (projectType === 'wall') return `Retaining wall and sloped-yard projects we build commonly land $30K–$90K+, with patio + wall + drainage packages often reaching ${fmtK(r.patioWallDrainage.low)}–${fmtK(r.patioWallDrainage.high)}.`;
  if (projectType === 'patio' || projectType === 'stone') return `Most premium patios and outdoor rooms we build land ${fmtK(r.premiumPatio.low)}–${fmtK(r.premiumPatio.high)} depending on size, access, base prep, drainage, and material choice — your configured scope above prices independently.`;
  if (selectedElements.includes('wall') && selectedElements.includes('patio')) return `Patio + wall/steps/drainage packages we build commonly land ${fmtK(r.patioWallDrainage.low)}–${fmtK(r.patioWallDrainage.high)} because the structure and water management are the job.`;
  return 'These are planning ranges from past projects, not a prediction for this build. Exact pricing depends on access, excavation, drainage, base depth, material choice, and whether walls, steps, lighting, or fire features are included.';
}
