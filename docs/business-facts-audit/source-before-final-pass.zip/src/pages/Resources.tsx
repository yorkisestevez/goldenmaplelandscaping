import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Clock, BookOpen, Calculator } from 'lucide-react';
import SEO from '../components/SEO';

const BLOG_POSTS = [
    {
    slug: "fire-pit-cost-barrie-with-permits",
    title: "Fire Pit Cost in Barrie: What You'll Pay in 2026 (With Permits)",
    excerpt: "Fire pit installation in Barrie costs $3,500–$18,000 depending on type; City of Barrie permits are required for gas work and any structure over 0.6 m².",
    category: "Investment",
    readTime: "11 min",
    image: "/images/projects/patio-pergola.jpg",
  },
  {
    slug: "landscaper-quote-excavation-line-item",
    title: "Landscaping Quote Excavation: Why Every Barrie Quote Needs This Line Item",
    excerpt: "A separate excavation line item in your landscaping quote is the only way to verify that site prep was properly priced — here's what it should include and what it costs in Barrie.",
    category: "Hiring Guide",
    readTime: "9 min",
    image: "/images/projects/paver-driveway.JPG",
  },
          {
    slug: "permacon-pavers-honest-review-2026",
    title: "Permacon Pavers: A Contractor's Honest Review (2026)",
    excerpt: "A Barrie hardscape contractor's honest review of Permacon pavers: installed cost $18–26/sq ft, top product lines, and trade-offs vs Unilock and Techo-Bloc.",
    category: "Materials",
    readTime: "10 min",
    image: "/images/projects/Permacon-approved.jpeg",
  },
  {
    slug: "pergola-vs-pavilion-vs-gazebo-barrie",
    title: "Pergola vs. Pavilion vs. Gazebo: Which Adds the Most Value in Barrie?",
    excerpt: "Pergolas cost $8,000–$18,000 installed in Barrie, pavilions $18,000–$45,000, gazebos $12,000–$30,000. Which structure adds the most value? Honest 2026 breakdown.",
    category: "Design",
    readTime: "9 min",
    image: "/images/projects/patio-pergola.jpg",
  },
  {
    slug: "outdoor-lighting-design-mistakes",
    title: "Landscape Lighting Mistakes That Make Homes Look Cheap in Simcoe County",
    excerpt: "Six landscape lighting mistakes — wrong colour temperature, over-lighting, and shallow cable burial — make Barrie homes look cheap. Here is the fix.",
    category: "Design",
    readTime: "9 min",
    image: "/images/projects/patio-pergola.jpg",
  },
  {
    slug: "failing-interlocking-patio-signs-barrie",
    title: "Failing Patio Signs in Barrie: 7 Things to Check Before It Costs You",
    excerpt: "Sunken pavers, wide joints, and pooling water are early signs of a failing patio in Barrie — catch them before repairs hit $8,000.",
    category: "Engineering",
    readTime: "9 min",
    image: "/images/projects/patio-pergola.jpg",
  },
  {
    slug: "composite-decking-maintenance-ontario",
    title: "Composite Decking Maintenance: What Actually Needs Doing Each Year",
    excerpt: "Ontario composite decks need 2 cleanings per year plus fall gap-clearing — the TimberTech routine that protects your 30-year warranty.",
    category: "Decking",
    readTime: "10 min",
    image: "/images/projects/TimberTech Dark Cocoa PrimeCollection Composite Decking Beauty1.jpg",
  },
  {
    slug: "spring-cleanup-checklist-barrie",
    title: "Spring Cleanup Checklist for Barrie Homeowners: 12 Tasks That Matter",
    excerpt: "After Barrie's freeze-thaw season, these 12 spring cleanup tasks protect interlocking pavers, drainage, and lawn areas from damage that costs 4x more to fix later.",
    category: "Seasonal",
    readTime: "10 min",
    image: "/images/projects/orillia-walkway.jpg",
  },
  {
    slug: "best-month-landscaping-project-barrie",
    title: "What Is the Best Month to Start a Landscaping Project in Barrie?",
    excerpt: "In Barrie, late April–May and September are the best months to start landscaping — fall booking lead times drop to 3–5 weeks versus 8–14 in peak summer.",
    category: "Seasonal",
    readTime: "9 min",
    image: "/images/projects/paver-driveway.JPG",
  },
  {
    slug: "backyard-drainage-solutions-barrie",
    title: "Backyard Drainage Barrie: 6 Solutions for Wet Yards That Actually Work",
    excerpt: "Wet backyard in Barrie? We cover 6 drainage solutions—from $1,500 French drains to $8,000+ catch basin systems—for Simcoe County clay soil.",
    category: "Engineering",
    readTime: "10 min",
    image: "/images/projects/garden-wall.JPEG",
  },
  {
    slug: "retaining-wall-engineer-required-ontario",
    title: "Retaining Wall Engineer Required in Ontario: Height Rules Explained",
    excerpt: "In Ontario, retaining walls over 1.0 metre typically require a permit and P.Eng. drawings — surcharge loads and Barrie clay can lower that threshold.",
    category: "Regulations",
    readTime: "10 min",
    image: "/images/projects/garden-wall.JPEG",
  },
                  {
    slug: "retaining-wall-cost-oro-medonte",
    title: "Retaining Wall Cost in Oro-Medonte: 2026 Price Breakdown",
    excerpt: "Retaining walls in Oro-Medonte cost $150–$350 per linear foot installed in 2026, depending on height, block brand, and whether engineering is required.",
    category: "Investment",
    readTime: "11 min",
    image: "/images/projects/garden-wall.JPEG",
  },
  {
    slug: "outdoor-living-planning-innisfil",
    title: "Outdoor Living Design Innisfil: 7-Step Planning Process",
    excerpt: "Planning an outdoor living space in Innisfil takes 7 steps — most projects run $25,000–$80,000 depending on zones, materials, and phasing strategy.",
    category: "Design",
    readTime: "11 min",
    image: "/images/projects/patio-pergola.jpg",
  },
  {
    slug: "natural-stone-vs-pavers-barrie",
    title: "Natural Stone vs. Pavers: A Buyer's Guide for Barrie Homeowners",
    excerpt: "Natural stone or concrete pavers for your Barrie patio? A contractor's honest take on cost, freeze-thaw durability, and long-term value in Simcoe County.",
    category: "Materials",
    readTime: "12 min",
    image: "/images/projects/orillia-walkway.jpg",
  },
  {
    slug: "concrete-vs-interlocking-patio-barrie",
    title: "Concrete vs Interlocking Patio: Best Choice for Barrie's Climate",
    excerpt: "Deciding between concrete and interlocking patios in Barrie involves weighing cost, durability, and style. Learn which suits Barrie's unique climate.",
    category: "Materials",
    readTime: "10 min",
    image: "/images/projects/Permacon-approved.jpeg",
  },
  {
    slug: "best-pavers-pool-deck-simcoe-county",
    title: "Best Pavers for Pool Decks in Simcoe County: Slip-Rated, Cool-Touch, Freeze-Thaw Tested",
    excerpt: "Best pavers for Simcoe County pool decks — slip-rated R-11 or higher, cool-touch light colours, freeze-thaw certified. Budget $25-45/sq ft installed.",
    category: "Materials",
    readTime: "9 min",
    image: "/images/projects/best.JPEG",
  },
  {
    slug: "interlocking-driveway-lifespan-ontario",
    title: "Interlocking Driveway Lifespan Ontario: How Long Pavers Really Last",
    excerpt: "A properly installed interlocking driveway in Ontario will last 25-50+ years, depending on the base preparation, paver quality, and regular maintenance.",
    category: "Engineering",
    readTime: "9 min",
    image: "/images/projects/paver-driveway.JPG",
  },
  {
    slug: "polymeric-sand-vs-regular-sand-patio",
    title: "Polymeric Sand vs. Regular Sand: Why It Matters for Your Barrie Patio",
    excerpt: "Wondering why your paver patio has weeds? Learn why polymeric sand is the only choice for durable interlocking patios in Barrie's harsh freeze-thaw cycles.",
    category: "Engineering",
    readTime: "9 min",
    image: "/images/projects/IHPX8926.JPEG",
  },
  {
    slug: "paver-walkway-cost-barrie",
    title: "What Does a Paver Walkway Cost in Barrie? Real 2026 Pricing Guide",
    excerpt: "Get real 2026 pricing for a paver walkway in Barrie, Ontario, and learn what factors like materials, base prep, and size will impact your final investment.",
    category: "Investment",
    readTime: "9 min",
    image: "/images/projects/orillia-walkway.jpg",
  },
  {
    slug: 'landscaping-cost-guide-barrie',
    title: 'How Much Does Landscaping Cost in Barrie? A 2026 Price Guide',
    excerpt: 'The definitive guide to landscaping costs in Barrie and Simcoe County. Authentic price ranges for interlocking, retaining walls, grading, and full property transformations.',
    category: 'Investment',
    readTime: '8 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'interlocking-patio-cost-ontario',
    title: 'How Much Does an Interlocking Patio Cost in Ontario?',
    excerpt: 'Detailed breakdown of what an interlocking patio costs in Ontario. Explains price factors like excavation, base materials, paver types, and exactly what drives the price.',
    category: 'Investment',
    readTime: '7 min',
    image: '/images/projects/patio-pergola.jpg',
  },
  {
    slug: 'hidden-costs-cheap-landscaping',
    title: 'The Hidden Costs of "Cheap" Landscaping',
    excerpt: 'Why accepting the lowest landscaping bid often costs double in the end. A look at the cut corners in cheap patio installations and failing retaining walls.',
    category: 'Investment',
    readTime: '6 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'why-patios-sink-barrie',
    title: 'Why Patios Sink in Barrie (And How to Prevent It)',
    excerpt: 'The freeze-thaw cycle destroys shallow bases. Learn why 12-16\" of compacted clear stone is the only way to build a patio that lasts in Simcoe County.',
    category: 'Engineering',
    readTime: '7 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'clear-stone-vs-granular-a-base',
    title: 'Clear Stone vs. Granular A: Why Your Patio Base Decides Everything',
    excerpt: '95% of Barrie contractors quote Granular A. It traps water, fails under freeze-thaw, and is the #1 reason hardscapes sink. Here\'s the ICPI open-graded alternative we build on.',
    category: 'Engineering',
    readTime: '9 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'timbertech-vs-wood-decking-ontario',
    title: 'TimberTech vs. Wood Decking: The Real Cost Over 20 Years',
    excerpt: 'Wood looks cheaper upfront — until you add up the staining, repairs, and replacements. Here\'s the honest math on composite vs. traditional decking in Ontario.',
    category: 'Decking',
    readTime: '8 min',
    image: '/images/projects/TimberTech Dark Cocoa PrimeCollection Composite Decking Beauty1.jpg',
  },
  {
    slug: 'retaining-wall-guide-simcoe-county',
    title: 'The Complete Guide to Retaining Walls in Simcoe County',
    excerpt: 'When do you need an engineer? What materials last longest? How deep should your base be? Everything homeowners need to know before building a retaining wall.',
    category: 'Retaining Walls',
    readTime: '10 min',
    image: '/images/projects/garden-wall.JPEG',
  },
  {
    slug: 'how-to-choose-landscaping-contractor-barrie',
    title: 'How to Choose a Landscaping Contractor in Barrie (Without Getting Burned)',
    excerpt: 'The 7 questions you must ask before signing any contract — and the red flags that tell you to walk away immediately.',
    category: 'Hiring Guide',
    readTime: '9 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'unilock-vs-techo-bloc-vs-permacon',
    title: 'Unilock vs. Techo-Bloc vs. Permacon: Which Paver is Right for Your Home?',
    excerpt: 'We install all three brands. Here\'s an honest comparison of durability, aesthetics, warranty, and cost — straight from the contractor who works with them daily.',
    category: 'Materials',
    readTime: '8 min',
    image: '/images/projects/IHPX8926.JPEG',
  },
  {
    slug: 'outdoor-kitchen-planning-guide',
    title: 'Planning an Outdoor Kitchen in Ontario: What You Need to Know',
    excerpt: 'Gas lines, countertop materials, drainage, and winter protection — the complete planning checklist for an outdoor kitchen that actually works year-round.',
    category: 'Outdoor Living',
    readTime: '7 min',
    image: '/images/projects/luxury outdoor kitchen.jpeg',
  },
  {
    slug: 'landscape-lighting-guide-barrie',
    title: 'Landscape Lighting: The Investment That Doubles Your Outdoor Living Hours',
    excerpt: 'Professional lighting transforms your property after dark. Learn about low-voltage LED systems, placement strategy, and why DIY kits don\'t compare.',
    category: 'Lighting',
    readTime: '6 min',
    image: '/images/projects/IHPX8926.JPEG',
  },
  {
    slug: 'winter-damage-prevention-interlocking',
    title: 'How to Protect Your Interlocking Stone From Winter Damage',
    excerpt: 'Salt, plows, and ice can destroy your patio. Here are the maintenance tips that will keep your interlocking looking perfect through every Barrie winter.',
    category: 'Maintenance',
    readTime: '5 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'backyard-renovation-roi-ontario',
    title: 'Does a Backyard Renovation Increase Home Value in Ontario?',
    excerpt: 'The data says yes — but only if it\'s done right. Here\'s what appraisers actually look for and which projects deliver the highest ROI in Simcoe County.',
    category: 'Investment',
    readTime: '7 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'fire-pit-regulations-barrie',
    title: 'Fire Pit Rules in Barrie: Permits, Setbacks, and What You Can Actually Build',
    excerpt: 'Before you build a fire feature, you need to know the rules. Here\'s a plain-English breakdown of Barrie\'s fire pit bylaws and how to stay compliant.',
    category: 'Regulations',
    readTime: '6 min',
    image: '/images/projects/cousy fire feature.jpeg',
  },
  {
    slug: 'best-time-install-patio-ontario',
    title: 'Best Time to Install a Paver Patio in Ontario (2026 Guide)',
    excerpt: 'Month-by-month breakdown of when to install in Barrie and Simcoe County. Booking lead times, weather windows, and how to lock 2026 pricing before mid-season hikes.',
    category: 'Project Planning',
    readTime: '9 min',
    image: '/images/projects/IMG_4826.jpg',
  },
  {
    slug: 'landscape-permits-barrie-simcoe',
    title: 'Permits, Bylaws & Inspections for Hardscape in Barrie & Simcoe County',
    excerpt: 'Complete 2026 reference: which projects need permits, the 1-metre retaining wall rule, municipality-by-municipality contact info, and Ontario One Call requirements.',
    category: 'Project Planning',
    readTime: '11 min',
    image: '/images/projects/garden-wall.JPEG',
  },
  {
    slug: 'pool-deck-materials-ontario',
    title: 'Pool Deck Materials Compared: Porcelain, Concrete Pavers, Natural Stone',
    excerpt: 'Full side-by-side breakdown of pool surround materials in Ontario — slip ratings, heat retention, real 2026 cost per sqft, and which fits salt-water vs chlorine pools.',
    category: 'Materials',
    readTime: '10 min',
    image: '/images/projects/decking1.jpg',
  },
];

export default function Resources() {
  return (
    <div className="bg-brand-nearblack min-h-screen">
      <SEO 
        title="Landscaping Resources & Expert Guides | Barrie & Simcoe County | Golden Maple"
        description="Expert landscaping guides, contractor hiring tips, material comparisons, and maintenance advice from Barrie's highest-rated hardscape contractor. Free resources to help you make informed decisions."
        canonical="https://goldenmaplelandscaping.ca/resources"
      />

      <section className="section-padding pt-40 md:pt-48">
        <div className="container-custom">
          <div className="max-w-3xl mb-24">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <span className="font-sans text-[11px] uppercase tracking-[0.3em] text-brand-gold-dark mb-8 block">Resources</span>
              <h1 className="font-display text-5xl md:text-8xl font-light text-brand-bonewhite leading-[1.05] mb-10">
                Expert guides for <br />
                <span className="italic text-brand-gold-dark">smarter homeowners.</span>
              </h1>
              <p className="font-sans text-lg text-brand-muted leading-relaxed font-light">
                Before you spend a dollar on your backyard, arm yourself with the knowledge that separates a 3-year patio from a 30-year one.
              </p>
            </motion.div>
          </div>

          {/* Buyer's Guide Feature Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="mb-24"
          >
            <Link to="/buyers-guide" className="group block">
              <div className="bg-brand-surface border border-brand-gold/20 rounded-[2px] p-10 md:p-16 flex flex-col md:flex-row items-center gap-12 hover:border-brand-gold/40 transition-all duration-500">
                <div className="w-20 h-20 bg-brand-gold/10 flex items-center justify-center rounded-full shrink-0 border border-brand-gold/20 group-hover:bg-brand-gold/20 transition-colors">
                  <BookOpen className="text-brand-gold" size={32} strokeWidth={1.5} />
                </div>
                <div className="flex-1">
                  <span className="font-sans text-[11px] uppercase tracking-[0.3em] text-brand-gold-dark mb-3 block">Featured Resource</span>
                  <h2 className="font-display text-3xl md:text-4xl font-light text-brand-bonewhite mb-4 group-hover:text-brand-gold-dark transition-colors">The Homeowner's Buyer's Guide</h2>
                  <p className="font-sans text-brand-muted font-light leading-relaxed">The complete guide to hiring the right landscaping contractor in Barrie. What to ask, what to expect, and how to protect your investment.</p>
                </div>
                <ArrowRight className="text-brand-gold shrink-0 group-hover:translate-x-2 transition-transform" size={24} strokeWidth={1.5} />
              </div>
            </Link>
          </motion.div>

          {/* Cost estimator band */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="mb-24"
          >
            <Link to="/cost-estimator" className="group block">
              <div className="bg-brand-surface border border-brand-gold/20 rounded-[2px] p-10 md:p-16 flex flex-col md:flex-row items-center gap-12 hover:border-brand-gold/40 transition-all duration-500">
                <div className="w-20 h-20 bg-brand-gold/10 flex items-center justify-center rounded-full shrink-0 border border-brand-gold/20 group-hover:bg-brand-gold/20 transition-colors">
                  <Calculator className="text-brand-gold" size={32} strokeWidth={1.5} />
                </div>
                <div className="flex-1">
                  <span className="font-sans text-[11px] uppercase tracking-[0.3em] text-brand-gold-dark mb-3 block">Free Tool</span>
                  <h2 className="font-display text-3xl md:text-4xl font-light text-brand-bonewhite mb-4 group-hover:text-brand-gold-dark transition-colors">What will your project cost?</h2>
                  <p className="font-sans text-brand-muted font-light leading-relaxed">Price your patio, wall, deck or full backyard in about two minutes — real Carr Landscape Depot pricing, no signup to see your range, and every choice shows exactly what it adds.</p>
                </div>
                <ArrowRight className="text-brand-gold shrink-0 group-hover:translate-x-2 transition-transform" size={24} strokeWidth={1.5} />
              </div>
            </Link>
          </motion.div>

          {/* Blog Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {BLOG_POSTS.map((post, idx) => (
              <motion.div
                key={post.slug}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.05 * idx }}
              >
                <Link to={`/resources/${post.slug}`} className="group block h-full">
                  <div className="bg-brand-surface border border-brand-dim/10 rounded-[2px] overflow-hidden h-full flex flex-col hover:border-brand-gold/20 transition-all duration-500">
                    <div className="aspect-[16/10] overflow-hidden">
                      <img
                        src={post.image}
                        alt={post.title}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                    </div>
                    <div className="p-8 flex flex-col flex-1">
                      <div className="flex items-center gap-4 mb-5">
                        <span className="font-sans text-[10px] uppercase tracking-[0.25em] text-brand-gold-dark font-medium">{post.category}</span>
                        <span className="flex items-center gap-1 font-sans text-[10px] uppercase tracking-[0.2em] text-brand-muted">
                          <Clock size={10} strokeWidth={1.5} /> {post.readTime}
                        </span>
                      </div>
                      <h3 className="font-display text-xl font-light text-brand-bonewhite mb-4 leading-tight group-hover:text-brand-gold-dark transition-colors">{post.title}</h3>
                      <p className="font-sans text-sm text-brand-muted font-light leading-relaxed flex-1">{post.excerpt}</p>
                      <div className="mt-6 flex items-center gap-3 font-sans text-[11px] uppercase tracking-[0.2em] text-brand-gold-dark group-hover:gap-5 transition-all">
                        Read Article <ArrowRight size={14} strokeWidth={1.5} />
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
