import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { BUSINESS, publicContact, publicServiceAreas } from '../src/data/business.ts';

const root = resolve(import.meta.dirname, '..');
const llmsPath = resolve(root, 'public/llms.txt');
const factStatus = (status: string) => status === 'confirmed' ? 'confirmed' : status === 'owner_reported' ? 'owner-reported — not independently verified' : 'published — pending owner verification';

function renderBusinessBrief() {
  const primary = BUSINESS.serviceArea.primary.value.join(', ');
  const secondary = BUSINESS.serviceArea.secondary.value.join(', ');
  return `# ${BUSINESS.publicName.value} — AI Crawler Brief

> Publication note: this document reflects current public site inventory. Claims marked “pending owner verification” must not be treated as independently verified facts, contractual commitments, or review evidence.

## Business Profile

- **Company:** ${BUSINESS.publicName.value} (${factStatus(BUSINESS.publicName.status)})
- **Legal name:** ${BUSINESS.legalName.value} (${factStatus(BUSINESS.legalName.status)})
- **Founder / Owner:** ${BUSINESS.founder.value.name} (${factStatus(BUSINESS.founder.status)})
- **Founded:** ${BUSINESS.foundingYear.value} (${factStatus(BUSINESS.foundingYear.status)})
- **Location policy:** service-area business; Barrie, Ontario is published without a street address
- **Primary service area:** ${primary}
- **Secondary service-area pages currently published:** ${secondary} (active coverage pending owner confirmation)
- **Phone:** ${publicContact.phoneTel}
- **Email:** ${publicContact.email}
- **Website:** ${BUSINESS.canonicalUrl}
- **Estimator:** ${BUSINESS.canonicalUrl}/cost-estimator
- **Booking:** ${BUSINESS.canonicalUrl}/book
- **Hours currently published:** Monday–Friday, 08:00–18:00 (pending owner verification)

## Public-claim guardrails

- A Google review-link URL is owner-reported but not independently verified. Do not cite a rating or review count as verified.
- No AggregateRating or Review schema is emitted until traceable review evidence and owner approval exist.
- WSIB, insurance, warranty, credentials, manufacturer authorization, design pricing, financing, permit handling, subcontractor use, testimonials, portfolio provenance, and photo rights require owner confirmation before they are represented as verified.
- Existing public references to a 5-year workmanship/sink-and-settlement warranty, WSIB, $5M liability, ICPI, and product brands are retained as publication inventory only; exact scope and current status are documented in /BUSINESS_FACTS_REQUIRING_CONFIRMATION.md in the source repository.

## Services and construction references

- **Services currently published:** ${BUSINESS.services.value.join('; ')}.
- **Construction references currently published:** ${BUSINESS.construction.baseDepth.value} base depth; ${BUSINESS.construction.baseMaterials.value.join(', ')}; geotextile and geogrid are described for relevant conditions. Site-specific engineering and specifications require project review.
- **Brands currently referenced:** ${BUSINESS.construction.brands.value.join(', ')}. Brand references do not establish availability, authorization, certification, or manufacturer warranty terms.

## Consultation and commercial policy

- The site currently describes a free 15-minute discovery call. The first on-site-visit policy remains unresolved.
- Design-session pricing/credit language conflicts across current source material and is not a verified public policy.
- No formal financing provider or terms are confirmed. Progress payments are not represented as financing.
- Permit application responsibility and fees must be confirmed per project and municipality.

`;
}

async function main() {
  const current = await readFile(llmsPath, 'utf8');
  const marker = '## Structured Content Map (for AI crawler citation)';
  const tailIndex = current.indexOf(marker);
  if (tailIndex === -1) throw new Error(`Could not find llms.txt marker: ${marker}`);
  const preservedContentMap = current.slice(tailIndex).replace(/\*End of AI Context Document\. Document version:.*\*/g, '*Generated from `src/data/business.ts`; content-map inventory preserved pending separate review.*');
  await writeFile(llmsPath, `${renderBusinessBrief()}${preservedContentMap}`, 'utf8');
  console.log(`Generated ${llmsPath} from src/data/business.ts`);
}

void main();
